import cv2 as cv
import cv2.aruco as aruco
import numpy as np
import socket
import time
import math

# ================== CẤU HÌNH ESP32 ==================
ESP32_IP = "192.168.1.50"      # <-- Sửa thành IP ESP32 của bạn
ESP32_PORT = 5000              # Phải trùng với port trong code ESP32

def send_command(cmd: str):
    """
    Gửi 1 lệnh dạng chuỗi tới ESP32.
    Ví dụ:
        send_command("MOVE 20")
        send_command("TURN -30")
        send_command("STOP")
    """
    cmd = cmd.strip() + "\n"
    print(f"[TX] {cmd.strip()}")
    try:
        with socket.socket(socket.AF_INET, socket.SOCK_STREAM) as s:
            s.settimeout(1.0)
            s.connect((ESP32_IP, ESP32_PORT))
            s.sendall(cmd.encode("utf-8"))
    except Exception as e:
        print("[LỖI] Không gửi được lệnh tới ESP32:", e)


# ================== XỬ LÝ ARUCO ==================
def detect_aruco(frame, aruco_dict, parameters):
    gray = cv.cvtColor(frame, cv.COLOR_BGR2GRAY)
    corners, ids, _ = aruco.detectMarkers(gray, aruco_dict, parameters=parameters)
    if ids is not None:
        aruco.drawDetectedMarkers(frame, corners, ids)
    return corners, ids


def control_from_marker(frame, corners, ids, target_id=None):
    """
    Logic điều khiển cực đơn giản:
    - Chọn marker lớn nhất (hoặc marker có id = target_id nếu được chỉ định)
    - Nếu marker lệch sang trái/phải so với tâm ảnh → QUAY
    - Nếu marker gần ở giữa → TIẾN TỚI
    """

    h, w, _ = frame.shape
    cx_img = w / 2

    if ids is None or len(ids) == 0:
        # Không thấy marker nào → có thể STOP hoặc quay tìm
        # Ở đây demo là STOP
        # send_command("STOP")
        return

    # Chọn marker
    chosen_index = 0
    if target_id is not None:
        # Tìm marker đúng ID
        for i, mid in enumerate(ids):
            if int(mid[0]) == target_id:
                chosen_index = i
                break

    # Lấy 4 điểm góc của marker được chọn
    pts = corners[chosen_index][0]   # shape (4,2)
    # Tính tâm marker
    cx = np.mean(pts[:, 0])
    cy = np.mean(pts[:, 1])

    # Vẽ lên ảnh cho trực quan
    cv.circle(frame, (int(cx), int(cy)), 5, (0, 0, 255), -1)
    cv.line(frame, (int(cx_img), 0), (int(cx_img), h), (255, 0, 0), 1)

    # Sai số ngang
    error_x = cx - cx_img

    # Ngưỡng để coi như "thẳng"
    dead_zone = w * 0.1   # 10% chiều ngang

    if abs(error_x) < dead_zone:
        # Marker khá ở giữa → đi thẳng nhẹ
        send_command("MOVE 5")   # 5 đơn vị (tùy bạn map sang thời gian/độ dài)
    else:
        # Cần quay
        # Tỉ lệ sai số -> góc quay
        max_angle = 45.0  # độ
        norm = error_x / (w / 2)
        turn_angle = max_angle * norm   # dương: lệch phải, âm: lệch trái
        # Trong quy ước mình dùng ở ESP32:
        # TURN > 0 quay phải, < 0 quay trái
        send_command(f"TURN {turn_angle:.1f}")


# ================== HÀM CHÍNH ==================
def main():
    # Mở webcam laptop
    cap = cv.VideoCapture(0)
    if not cap.isOpened():
        print("[LỖI] Không mở được webcam!")
        return

    # Tạo dictionary ArUco
    aruco_dict = aruco.getPredefinedDictionary(aruco.DICT_4X4_250)
    parameters = aruco.DetectorParameters_create()

    # Nếu bạn muốn robot đuổi theo một ID marker cụ thể, set ở đây
    TARGET_ID = None  # hoặc ví dụ: 1, 2, 3,...

    print("Bấm 'q' để thoát.")

    last_cmd_time = 0
    cmd_interval = 0.5   # gửi lệnh mỗi 0.5 giây để tránh spam

    while True:
        ret, frame = cap.read()
        if not ret:
            print("[LỖI] Không đọc được frame từ webcam.")
            break

        corners, ids = detect_aruco(frame, aruco_dict, parameters)

        now = time.time()
        if now - last_cmd_time > cmd_interval:
            control_from_marker(frame, corners, ids, target_id=TARGET_ID)
            last_cmd_time = now

        cv.imshow("ArUco Robot Control (Laptop -> ESP32)", frame)
        key = cv.waitKey(1) & 0xFF
        if key == ord('q'):
            break

    # Khi thoát
    send_command("STOP")
    cap.release()
    cv.destroyAllWindows()


if __name__ == "__main__":
    main()
