
# aruco_agv_sim.py
# Simple ArUco-based AGV control demo (simulation).
# - Simulates a camera view of an ArUco marker
# - Detects marker with OpenCV ArUco
# - Converts pose (tvec) to AGV commands: forward/back + left/right turning (v, w)
#
# Install:
#   pip install opencv-contrib-python numpy
#
# Run:
#   python aruco_agv_sim.py

import math
import time
from dataclasses import dataclass

import cv2
import numpy as np


def clamp(x, lo, hi):
    return max(lo, min(hi, x))


def make_aruco_image(dictionary, marker_id: int, px: int = 300) -> np.ndarray:
    """Compatibility helper: generate a marker image across OpenCV versions."""
    img = np.zeros((px, px), dtype=np.uint8)
    # Newer OpenCV: generateImageMarker
    if hasattr(cv2.aruco, "generateImageMarker"):
        cv2.aruco.generateImageMarker(dictionary, marker_id, px, img, 1)
    else:
        # Older: drawMarker
        cv2.aruco.drawMarker(dictionary, marker_id, px, img, 1)
    return img


def make_detector(dictionary):
    """Compatibility helper: create a detector across OpenCV versions."""
    if hasattr(cv2.aruco, "DetectorParameters"):
        params = cv2.aruco.DetectorParameters()
    else:
        params = cv2.aruco.DetectorParameters_create()

    if hasattr(cv2.aruco, "ArucoDetector"):
        detector = cv2.aruco.ArucoDetector(dictionary, params)
        return detector, None, params
    return None, None, params


def detect_markers(gray, dictionary, detector, params):
    if detector is not None:
        corners, ids, rejected = detector.detectMarkers(gray)
    else:
        corners, ids, rejected = cv2.aruco.detectMarkers(gray, dictionary, parameters=params)
    return corners, ids, rejected


@dataclass
class SimState:
    # "True" relative state (marker -> camera), simplified
    x: float = 0.15      # meters, left/right offset (camera X)
    z: float = 1.20      # meters, distance to marker (camera Z)
    yaw: float = 0.20    # radians, rotation around Y axis (turning)
    auto: bool = True


def render_marker_view(
    marker_img: np.ndarray,
    marker_len_m: float,
    K: np.ndarray,
    dist: np.ndarray,
    state: SimState,
    W: int,
    H: int,
) -> np.ndarray:
    """Render a synthetic camera frame with the ArUco marker projected via homography."""
    frame = np.full((H, W, 3), 235, dtype=np.uint8)  # light background

    # 3D marker corners in marker frame (Z=0 plane), centered at origin.
    s = marker_len_m / 2.0
    obj = np.array(
        [[-s,  s, 0.0],
         [ s,  s, 0.0],
         [ s, -s, 0.0],
         [-s, -s, 0.0]],
        dtype=np.float32
    )

    # Rotation: yaw around Y axis.
    cy, sy = math.cos(state.yaw), math.sin(state.yaw)
    R = np.array([[ cy, 0.0,  sy],
                  [0.0, 1.0, 0.0],
                  [-sy, 0.0,  cy]], dtype=np.float32)
    rvec, _ = cv2.Rodrigues(R)

    # Translation: marker origin in camera coordinates.
    tvec = np.array([[state.x], [0.0], [state.z]], dtype=np.float32)

    img_pts, _ = cv2.projectPoints(obj, rvec, tvec, K, dist)  # (4,1,2)
    pts = img_pts.reshape(-1, 2).astype(np.float32)

    # If marker goes out of view or behind camera, just return background.
    if state.z <= 0.05:
        return frame
    if np.any(np.isnan(pts)) or np.any(np.isinf(pts)):
        return frame

    # Source points in marker image
    m = marker_img.shape[0]
    src = np.array([[0, 0], [m - 1, 0], [m - 1, m - 1], [0, m - 1]], dtype=np.float32)

    # Compute homography and warp marker into frame
    Hm, ok = cv2.findHomography(src, pts, method=0)
    if Hm is None:
        return frame

    marker_bgr = cv2.cvtColor(marker_img, cv2.COLOR_GRAY2BGR)
    warped = cv2.warpPerspective(marker_bgr, Hm, (W, H), flags=cv2.INTER_LINEAR)

    # Create mask where warped marker pixels are "dark enough"
    warped_gray = cv2.cvtColor(warped, cv2.COLOR_BGR2GRAY)
    mask = (warped_gray < 250).astype(np.uint8) * 255  # binary mask
    mask3 = cv2.cvtColor(mask, cv2.COLOR_GRAY2BGR)

    # Composite: overlay the warped marker
    frame = cv2.bitwise_and(frame, cv2.bitwise_not(mask3))
    frame = cv2.bitwise_or(frame, cv2.bitwise_and(warped, mask3))

    # Add a bit of noise for realism
    noise = np.random.normal(0, 3.0, frame.shape).astype(np.int16)
    frame = np.clip(frame.astype(np.int16) + noise, 0, 255).astype(np.uint8)

    return frame


def draw_topdown(state: SimState, v: float, w: float, desired_z: float) -> np.ndarray:
    """Simple top-down map image."""
    S = 600
    img = np.full((S, S, 3), 250, dtype=np.uint8)

    # Coordinate: marker at center; x right, z down
    cx, cz = S // 2, S // 2
    scale = 180  # pixels per meter

    # Draw marker as a small square at origin
    cv2.rectangle(img, (cx - 18, cz - 18), (cx + 18, cz + 18), (0, 0, 0), 2)
    cv2.putText(img, "Marker", (cx + 22, cz - 10), cv2.FONT_HERSHEY_SIMPLEX, 0.6, (30, 30, 30), 2)

    # Desired distance line
    dz = int(desired_z * scale)
    cv2.line(img, (0, cz + dz), (S, cz + dz), (180, 180, 180), 2)
    cv2.putText(img, f"z_des={desired_z:.2f}m", (10, cz + dz - 10), cv2.FONT_HERSHEY_SIMPLEX, 0.6, (80, 80, 80), 2)

    # Robot/camera position in this simplified sim: (x, z) from pose params
    px = int(cx + state.x * scale)
    pz = int(cz + state.z * scale)

    # Draw robot
    cv2.circle(img, (px, pz), 10, (40, 40, 220), -1)

    # Heading arrow (yaw around Y axis => turn left/right)
    # We'll draw an arrow showing where camera is "pointing" in x-z plane.
    # In this sim, yaw=0 points "up" towards marker (negative z direction on map).
    arrow_len = 40
    dx = int(arrow_len * math.sin(state.yaw))
    dz2 = int(arrow_len * math.cos(state.yaw))
    # pointing towards marker => up means -dz2
    tip = (px + dx, pz - dz2)
    cv2.arrowedLine(img, (px, pz), tip, (40, 40, 220), 2, tipLength=0.25)

    # HUD text
    mode = "AUTO" if state.auto else "MANUAL"
    cv2.putText(img, f"Mode: {mode}", (10, 30), cv2.FONT_HERSHEY_SIMPLEX, 0.8, (20, 20, 20), 2)
    cv2.putText(img, f"x={state.x:+.3f} m   z={state.z:.3f} m   yaw={math.degrees(state.yaw):+.1f} deg",
                (10, 60), cv2.FONT_HERSHEY_SIMPLEX, 0.6, (20, 20, 20), 2)
    cv2.putText(img, f"cmd v={v:+.2f} m/s   w={math.degrees(w):+.1f} deg/s",
                (10, 90), cv2.FONT_HERSHEY_SIMPLEX, 0.6, (20, 20, 20), 2)
    cv2.putText(img, "Keys: q quit | m toggle auto/manual | w/s forward/back | a/d turn | x stop",
                (10, S - 20), cv2.FONT_HERSHEY_SIMPLEX, 0.55, (60, 60, 60), 2)
    return img


def main():
    # ---- Settings ----
    W, H = 640, 480
    marker_id = 0
    marker_len_m = 0.12

    # Camera intrinsics (simple pinhole model)
    fx = fy = 800.0
    cx = W / 2.0
    cy = H / 2.0
    K = np.array([[fx, 0, cx],
                  [0, fy, cy],
                  [0,  0,  1]], dtype=np.float32)
    dist = np.zeros((5, 1), dtype=np.float32)

    dictionary = cv2.aruco.getPredefinedDictionary(cv2.aruco.DICT_4X4_50)
    marker_img = make_aruco_image(dictionary, marker_id, px=320)
    detector, _, params = make_detector(dictionary)

    state = SimState()
    desired_z = 0.70  # stand-off distance to marker

    # Controller gains (keep small, this is a demo)
    k_v = 0.9
    k_w = 2.0
    v_max = 0.45
    w_max = math.radians(120)

    # Manual commands
    v_man = 0.0
    w_man = 0.0

    last = time.time()

    while True:
        now = time.time()
        dt = now - last
        last = now
        dt = clamp(dt, 1e-3, 0.1)

        # 1) Render synthetic camera frame
        frame = render_marker_view(marker_img, marker_len_m, K, dist, state, W, H)

        # 2) Detect ArUco marker
        gray = cv2.cvtColor(frame, cv2.COLOR_BGR2GRAY)
        corners, ids, _ = detect_markers(gray, dictionary, detector, params)

        v_cmd = 0.0
        w_cmd = 0.0

        if ids is not None and len(ids) > 0:
            # Draw detected marker
            cv2.aruco.drawDetectedMarkers(frame, corners, ids)

            # Pose estimation
            rvecs, tvecs, _objPoints = cv2.aruco.estimatePoseSingleMarkers(
                corners, marker_len_m, K, dist
            )

            rvec = rvecs[0].reshape(3, 1)
            tvec = tvecs[0].reshape(3, 1)

            # Draw axes (OpenCV helper)
            cv2.drawFrameAxes(frame, K, dist, rvec, tvec, marker_len_m * 0.75)

            # Read pose components
            x_est = float(tvec[0])
            z_est = float(tvec[2])

            if state.auto:
                # Simple control:
                # - forward/back: keep z close to desired_z
                # - left/right turning: reduce x offset
                v_cmd = clamp(k_v * (z_est - desired_z), -v_max, v_max)
                w_cmd = clamp(-k_w * x_est, -w_max, w_max)
            else:
                v_cmd, w_cmd = v_man, w_man

            # On-frame text
            cv2.putText(frame, f"tvec: x={x_est:+.3f}m  z={z_est:.3f}m",
                        (10, 30), cv2.FONT_HERSHEY_SIMPLEX, 0.65, (10, 10, 10), 2)
            cv2.putText(frame, f"cmd: v={v_cmd:+.2f} m/s  w={math.degrees(w_cmd):+.1f} deg/s",
                        (10, 60), cv2.FONT_HERSHEY_SIMPLEX, 0.65, (10, 10, 10), 2)
        else:
            # No marker found: stop
            v_cmd = 0.0
            w_cmd = 0.0
            cv2.putText(frame, "No marker detected -> STOP",
                        (10, 30), cv2.FONT_HERSHEY_SIMPLEX, 0.7, (20, 20, 20), 2)

        # 3) Update simulated "true" state using cmd
        # This is a crude kinematic update in the marker frame:
        # dist decreases when moving forward; yaw changes with w; x shifts when moving with yaw.
        state.yaw += w_cmd * dt
        state.yaw = (state.yaw + math.pi) % (2 * math.pi) - math.pi  # wrap [-pi, pi]

        state.z -= v_cmd * dt * math.cos(state.yaw)
        state.x += v_cmd * dt * math.sin(state.yaw)

        # keep within reasonable bounds
        state.z = clamp(state.z, 0.25, 2.5)
        state.x = clamp(state.x, -0.9, 0.9)

        # 4) Show windows
        top = draw_topdown(state, v_cmd, w_cmd, desired_z)
        cv2.imshow("Sim Camera (ArUco pose -> AGV cmd)", frame)
        cv2.imshow("Topdown (simulation)", top)

        # 5) Keys
        key = cv2.waitKey(1) & 0xFF
        if key == ord('q'):
            break
        if key == ord('m'):
            state.auto = not state.auto
            v_man, w_man = 0.0, 0.0

        if not state.auto:
            # Manual: WASD + x stop
            step_v = 0.30
            step_w = math.radians(90)
            if key == ord('w'):
                v_man = +step_v
            elif key == ord('s'):
                v_man = -step_v
            elif key == ord('a'):
                w_man = +step_w
            elif key == ord('d'):
                w_man = -step_w
            elif key == ord('x'):
                v_man, w_man = 0.0, 0.0
            else:
                # decay to 0 for smoother control
                v_man *= 0.92
                w_man *= 0.92

    cv2.destroyAllWindows()


if __name__ == "__main__":
    main()
