import heapq
from dataclasses import dataclass

import cv2
import numpy as np

# ---------------------- Map config ----------------------
CELL = 28
GRID_W, GRID_H = 32, 20
WIN_W = GRID_W * CELL
WIN_H = GRID_H * CELL + 110

RECEIVING = (1, 13, 8, 19)
CHARGING  = (24, 13, 31, 19)
STORAGE_ZONE = (10, 2, 22, 12)

TARGET_RECEIVING = (4, 16)
TARGET_STORAGE   = (20, 10)
TARGET_CHARGING  = (27, 16)

def make_obstacles():
    occ = np.zeros((GRID_H, GRID_W), dtype=np.uint8)
    x0, y0, x1, y1 = STORAGE_ZONE
    for x in range(x0+1, x1-1, 3):
        for y in range(y0+1, y1-1):
            if y in (5, 6, 9):  # aisles
                continue
            occ[y, x] = 1
    for x in range(13, 16):
        occ[12, x] = 1
    return occ

OCC = make_obstacles()

# --------------------------------------------------------

@dataclass
class AGV:
    x: int = 3
    y: int = 17
    battery: float = 1.0
    carrying: bool = False
    path: list = None

def in_bounds(x, y): return 0 <= x < GRID_W and 0 <= y < GRID_H
def is_free(x, y): return in_bounds(x, y) and OCC[y, x] == 0

def astar(start, goal):
    sx, sy = start
    gx, gy = goal
    if not is_free(gx, gy):
        return []

    def h(x, y): return abs(x - gx) + abs(y - gy)

    open_heap = []
    heapq.heappush(open_heap, (h(sx, sy), 0, (sx, sy)))
    came = {(sx, sy): None}
    gscore = {(sx, sy): 0}

    while open_heap:
        _, g, (x, y) = heapq.heappop(open_heap)
        if (x, y) == (gx, gy):
            path = []
            cur = (x, y)
            while cur is not None:
                path.append(cur)
                cur = came[cur]
            path.reverse()
            return path[1:]

        for dx, dy in ((1,0), (-1,0), (0,1), (0,-1)):
            nx, ny = x + dx, y + dy
            if not is_free(nx, ny):
                continue
            ng = g + 1
            if (nx, ny) not in gscore or ng < gscore[(nx, ny)]:
                gscore[(nx, ny)] = ng
                came[(nx, ny)] = (x, y)
                heapq.heappush(open_heap, (ng + h(nx, ny), ng, (nx, ny)))
    return []

def cell_to_px(x, y): return int(x * CELL), int(y * CELL)

def draw_zone(img, rect, label, color):
    x0, y0, x1, y1 = rect
    px0, py0 = cell_to_px(x0, y0)
    px1, py1 = cell_to_px(x1, y1)
    cv2.rectangle(img, (px0, py0), (px1*CELL, py1*CELL), color, -1)
    cv2.rectangle(img, (px0, py0), (px1*CELL, py1*CELL), (60,60,60), 2)
    cv2.putText(img, label, (px0+6, py0+24), cv2.FONT_HERSHEY_SIMPLEX, 0.75, (20,20,20), 2)

def draw_grid(img):
    for x in range(GRID_W + 1):
        cv2.line(img, (x*CELL, 0), (x*CELL, GRID_H*CELL), (235,235,235), 1)
    for y in range(GRID_H + 1):
        cv2.line(img, (0, y*CELL), (GRID_W*CELL, y*CELL), (235,235,235), 1)

def draw_obstacles(img):
    ys, xs = np.where(OCC == 1)
    for y, x in zip(ys, xs):
        px, py = cell_to_px(x, y)
        cv2.rectangle(img, (px, py), (px+CELL, py+CELL), (110,110,110), -1)
        cv2.rectangle(img, (px, py), (px+CELL, py+CELL), (70,70,70), 1)

def draw_target(img, target, label):
    x, y = target
    px, py = cell_to_px(x, y)
    cv2.circle(img, (px+CELL//2, py+CELL//2), 9, (10,10,10), -1)
    cv2.putText(img, label, (px+CELL//2+10, py+CELL//2+6), cv2.FONT_HERSHEY_SIMPLEX, 0.55, (10,10,10), 2)

def draw_path(img, path):
    if not path: return
    for (x, y) in path:
        px, py = cell_to_px(x, y)
        cv2.rectangle(img, (px+8, py+8), (px+CELL-8, py+CELL-8), (40,180,40), -1)

def draw_agv(img, agv: AGV):
    px, py = cell_to_px(agv.x, agv.y)
    cx, cy = px + CELL//2, py + CELL//2
    cv2.circle(img, (cx, cy), 11, (40,40,230), -1)
    cv2.circle(img, (cx, cy), 11, (20,20,20), 2)
    if agv.carrying:
        cv2.rectangle(img, (cx-7, cy-20), (cx+7, cy-6), (0,0,0), -1)
        cv2.putText(img, "BOX", (cx-18, cy-25), cv2.FONT_HERSHEY_SIMPLEX, 0.45, (0,0,0), 2)

def draw_hud(canvas, agv: AGV, mode: str, info: str):
    hud = np.full((110, WIN_W, 3), 255, dtype=np.uint8)
    bx0, by0 = 12, 18
    bw, bh = 210, 20
    cv2.rectangle(hud, (bx0, by0), (bx0+bw, by0+bh), (30,30,30), 2)
    fill = int(bw * max(0.0, min(1.0, agv.battery)))
    cv2.rectangle(hud, (bx0+2, by0+2), (bx0+2+fill, by0+bh-2), (40,180,40), -1)
    cv2.putText(hud, f"Battery: {agv.battery*100:.0f}%", (bx0, by0+50), cv2.FONT_HERSHEY_SIMPLEX, 0.75, (0,0,0), 2)
    cv2.putText(hud, f"Mode: {mode}", (260, 40), cv2.FONT_HERSHEY_SIMPLEX, 0.9, (0,0,0), 3)
    cv2.putText(hud, info, (260, 80), cv2.FONT_HERSHEY_SIMPLEX, 0.65, (30,30,30), 2)
    cv2.putText(
        hud,
        "Keys: q quit | w/a/s/d move | 1 receiving | 2 storage | 3 charging | space stop auto | r reset",
        (12, 102),
        cv2.FONT_HERSHEY_SIMPLEX, 0.55, (70,70,70), 2
    )
    canvas[GRID_H*CELL:GRID_H*CELL+110, 0:WIN_W] = hud

def at_cell(agv: AGV, target): return (agv.x, agv.y) == target
def in_rect(x, y, rect):
    x0, y0, x1, y1 = rect
    return x0 <= x < x1 and y0 <= y < y1

def main():
    agv = AGV()
    agv.path = []
    mode = "MANUAL"
    mission = "Idle"

    while True:
        canvas = np.full((WIN_H, WIN_W, 3), 255, dtype=np.uint8)
        world = canvas[:GRID_H*CELL, :]

        draw_zone(world, RECEIVING,    "RECEIVING", (220, 245, 255))
        draw_zone(world, STORAGE_ZONE, "STORAGE",   (245, 255, 220))
        draw_zone(world, CHARGING,     "CHARGING",  (255, 235, 220))

        draw_grid(world)
        draw_obstacles(world)

        draw_target(world, TARGET_RECEIVING, "Pick")
        draw_target(world, TARGET_STORAGE, "Drop")
        draw_target(world, TARGET_CHARGING, "Charge")

        draw_path(world, agv.path)
        draw_agv(world, agv)

        # battery
        if mode == "AUTO" and agv.path:
            agv.battery = max(0.0, agv.battery - 0.002)
        else:
            agv.battery = max(0.0, agv.battery - 0.0003)
        if in_rect(agv.x, agv.y, CHARGING):
            agv.battery = min(1.0, agv.battery + 0.01)

        # auto step
        if mode == "AUTO" and agv.path:
            nx, ny = agv.path.pop(0)
            agv.x, agv.y = nx, ny

        # mission logic: receiving -> storage -> (charge if low)
        if mission == "Go RECEIVING" and at_cell(agv, TARGET_RECEIVING):
            agv.carrying = True
            mission = "Go STORAGE"
            agv.path = astar((agv.x, agv.y), TARGET_STORAGE)

        if mission == "Go STORAGE" and at_cell(agv, TARGET_STORAGE):
            agv.carrying = False
            if agv.battery < 0.35:
                mission = "Go CHARGING"
                agv.path = astar((agv.x, agv.y), TARGET_CHARGING)
            else:
                mission = "Idle"
                mode = "MANUAL"
                agv.path = []

        if mission == "Go CHARGING" and at_cell(agv, TARGET_CHARGING):
            if agv.battery > 0.85:
                mission = "Idle"
                mode = "MANUAL"
                agv.path = []

        info = f"Mission: {mission} | Carrying: {agv.carrying}"
        draw_hud(canvas, agv, mode, info)

        cv2.imshow("AGV Warehouse Sandbox (Sa ban mo phong)", canvas)

        key = cv2.waitKey(80) & 0xFF
        if key == ord('q'):
            break

        if key in (ord('w'), ord('a'), ord('s'), ord('d')):
            mode = "MANUAL"
            agv.path = []
            dx, dy = 0, 0
            if key == ord('w'): dy = -1
            if key == ord('s'): dy = +1
            if key == ord('a'): dx = -1
            if key == ord('d'): dx = +1
            nx, ny = agv.x + dx, agv.y + dy
            if is_free(nx, ny):
                agv.x, agv.y = nx, ny

        if key == ord('1'):
            mode = "AUTO"
            mission = "Go RECEIVING"
            agv.path = astar((agv.x, agv.y), TARGET_RECEIVING)

        if key == ord('2'):
            mode = "AUTO"
            mission = "Go STORAGE"
            agv.path = astar((agv.x, agv.y), TARGET_STORAGE)

        if key == ord('3'):
            mode = "AUTO"
            mission = "Go CHARGING"
            agv.path = astar((agv.x, agv.y), TARGET_CHARGING)

        if key == ord(' '):
            mode = "MANUAL"
            mission = "Idle"
            agv.path = []

        if key == ord('r'):
            agv.x, agv.y = 3, 17
            agv.battery = 1.0
            agv.carrying = False
            agv.path = []
            mode = "MANUAL"
            mission = "Idle"

    cv2.destroyAllWindows()

if __name__ == "__main__":
    main()
