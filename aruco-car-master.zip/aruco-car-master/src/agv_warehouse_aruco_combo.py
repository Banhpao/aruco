
# agv_warehouse_aruco_combo.py
# Kết hợp "sa bàn kho" + điều khiển AGV bằng ArUco từ webcam.
#
# Bạn mở marker trên điện thoại (full screen) và đưa trước camera:
#   ID 0 -> FORWARD  (AGV đi lên)
#   ID 1 -> BACKWARD (AGV đi xuống)
#   ID 2 -> LEFT     (AGV đi trái)
#   ID 3 -> RIGHT    (AGV đi phải)
#   ID 4 -> STOP
#
# (Tuỳ chọn) Marker nhiệm vụ:
#   ID 10 -> GO RECEIVING (đi tới khu nhận hàng)
#   ID 11 -> GO STORAGE   (đi tới khu chứa / điểm drop)
#   ID 12 -> GO CHARGING  (đi tới khu sạc)
#
# Cài:
#   pip install opencv-contrib-python numpy
#
# Chạy:
#   python agv_warehouse_aruco_combo.py
#
# Phím:
#   q  thoát
#   m  bật/tắt vẽ pose axes trên camera
#   k  bật/tắt điều khiển bằng bàn phím (fallback)
#   w/a/s/d điều khiển AGV (khi keyboard control bật)
#   r  reset AGV
#
# Ghi chú:
# - Đây là mô phỏng 2D grid đơn giản (nhẹ) để demo.
# - Nếu bạn có calib camera thật: tạo file calib_cam.npz với keys:
#     camera_matrix, dist_coeffs  (OpenCV format)

import time
import heapq
from dataclasses import dataclass

import cv2
import numpy as np

# ---------------------- Camera / ArUco config ----------------------
CAM_INDEX = 0
DICT = cv2.aruco.DICT_4X4_50
MARKER_LENGTH_M = 0.06
CALIB_FILE = "calib_cam.npz"

CMD_MAP = {
    0: "tien",
    1: "lui",
    2: "trai",
    3: "phai",
    4: "STOP",
    10: "diem_nhan_hang",
    11: "diem_chua_hang",
    12: "diem_sac",
}

HOLD_SEC = 0.30  # giữ lệnh ngắn khi marker mất

# ---------------------- Sa bàn (warehouse) config ----------------------
CELL = 28
GRID_W, GRID_H = 32, 20
WIN_W = GRID_W * CELL
WIN_H = GRID_H * CELL + 110

RECEIVING = (1, 13, 8, 19)
CHARGING  = (24, 13, 31, 19)
STORAGE_ZONE = (10, 2, 22, 12)

TARGET_RECEIVING = (4, 16)
TARGET_STORAGE   = (20, 10)
TARGET_CHARGING  = (27, 16)

MOVE_PERIOD = 0.22  # seconds per grid step when using ArUco directional commands


def make_obstacles():
    occ = np.zeros((GRID_H, GRID_W), dtype=np.uint8)
    x0, y0, x1, y1 = STORAGE_ZONE
    # racks inside storage
    for x in range(x0 + 1, x1 - 1, 3):
        for y in range(y0 + 1, y1 - 1):
            if y in (5, 6, 9):  # aisles
                continue
            occ[y, x] = 1
    # extra obstacle row near storage exit
    for x in range(13, 16):
        if 0 <= 12 < GRID_H:
            occ[12, x] = 1
    return occ


OCC = make_obstacles()


@dataclass
class AGV:
    x: int = 3
    y: int = 17
    battery: float = 1.0
    carrying: bool = False
    path: list = None


def in_bounds(x, y): return 0 <= x < GRID_W and 0 <= y < GRID_H
def is_free(x, y): return in_bounds(x, y) and OCC[y, x] == 0


def astar(start, goal):
    sx, sy = start
    gx, gy = goal
    if not is_free(gx, gy):
        return []

    def h(x, y): return abs(x - gx) + abs(y - gy)

    open_heap = []
    heapq.heappush(open_heap, (h(sx, sy), 0, (sx, sy)))
    came = {(sx, sy): None}
    gscore = {(sx, sy): 0}

    while open_heap:
        _, g, (x, y) = heapq.heappop(open_heap)
        if (x, y) == (gx, gy):
            path = []
            cur = (x, y)
            while cur is not None:
                path.append(cur)
                cur = came[cur]
            path.reverse()
            return path[1:]

        for dx, dy in ((1,0), (-1,0), (0,1), (0,-1)):
            nx, ny = x + dx, y + dy
            if not is_free(nx, ny):
                continue
            ng = g + 1
            if (nx, ny) not in gscore or ng < gscore[(nx, ny)]:
                gscore[(nx, ny)] = ng
                came[(nx, ny)] = (x, y)
                heapq.heappush(open_heap, (ng + h(nx, ny), ng, (nx, ny)))
    return []


def cell_to_px(x, y): return int(x * CELL), int(y * CELL)


def draw_zone(img, rect, label, color):
    x0, y0, x1, y1 = rect
    px0, py0 = cell_to_px(x0, y0)
    cv2.rectangle(img, (px0, py0), (x1*CELL, y1*CELL), color, -1)
    cv2.rectangle(img, (px0, py0), (x1*CELL, y1*CELL), (60,60,60), 2)
    cv2.putText(img, label, (px0+6, py0+24), cv2.FONT_HERSHEY_SIMPLEX, 0.75, (20,20,20), 2)


def draw_grid(img):
    for x in range(GRID_W + 1):
        cv2.line(img, (x*CELL, 0), (x*CELL, GRID_H*CELL), (235,235,235), 1)
    for y in range(GRID_H + 1):
        cv2.line(img, (0, y*CELL), (GRID_W*CELL, y*CELL), (235,235,235), 1)


def draw_obstacles(img):
    ys, xs = np.where(OCC == 1)
    for y, x in zip(ys, xs):
        px, py = cell_to_px(x, y)
        cv2.rectangle(img, (px, py), (px+CELL, py+CELL), (110,110,110), -1)
        cv2.rectangle(img, (px, py), (px+CELL, py+CELL), (70,70,70), 1)


def draw_target(img, target, label):
    x, y = target
    px, py = cell_to_px(x, y)
    cv2.circle(img, (px+CELL//2, py+CELL//2), 9, (10,10,10), -1)
    cv2.putText(img, label, (px+CELL//2+10, py+CELL//2+6), cv2.FONT_HERSHEY_SIMPLEX, 0.55, (10,10,10), 2)


def draw_path(img, path):
    if not path:
        return
    for (x, y) in path:
        px, py = cell_to_px(x, y)
        cv2.rectangle(img, (px+8, py+8), (px+CELL-8, py+CELL-8), (40,180,40), -1)


def draw_agv(img, agv: AGV):
    px, py = cell_to_px(agv.x, agv.y)
    cx, cy = px + CELL//2, py + CELL//2
    cv2.circle(img, (cx, cy), 11, (40,40,230), -1)
    cv2.circle(img, (cx, cy), 11, (20,20,20), 2)
    if agv.carrying:
        cv2.rectangle(img, (cx-7, cy-20), (cx+7, cy-6), (0,0,0), -1)
        cv2.putText(img, "BOX", (cx-18, cy-25), cv2.FONT_HERSHEY_SIMPLEX, 0.45, (0,0,0), 2)


def in_rect(x, y, rect):
    x0, y0, x1, y1 = rect
    return x0 <= x < x1 and y0 <= y < y1


def draw_hud(canvas, agv: AGV, mode: str, info: str, cmd: str):
    hud = np.full((110, WIN_W, 3), 255, dtype=np.uint8)

    bx0, by0 = 12, 18
    bw, bh = 210, 20
    cv2.rectangle(hud, (bx0, by0), (bx0+bw, by0+bh), (30,30,30), 2)
    fill = int(bw * max(0.0, min(1.0, agv.battery)))
    cv2.rectangle(hud, (bx0+2, by0+2), (bx0+2+fill, by0+bh-2), (40,180,40), -1)
    cv2.putText(hud, f"Battery: {agv.battery*100:.0f}%", (bx0, by0+50), cv2.FONT_HERSHEY_SIMPLEX, 0.75, (0,0,0), 2)

    cv2.putText(hud, f"Mode: {mode}", (260, 40), cv2.FONT_HERSHEY_SIMPLEX, 0.9, (0,0,0), 3)
    cv2.putText(hud, f"CMD: {cmd}", (260, 80), cv2.FONT_HERSHEY_SIMPLEX, 0.75, (0,0,0), 2)
    cv2.putText(hud, info, (520, 80), cv2.FONT_HERSHEY_SIMPLEX, 0.6, (30,30,30), 2)

    cv2.putText(
        hud,
        "q quit | m pose | k keyboard ctl | w/a/s/d move (if keyboard on) | r reset",
        (12, 102),
        cv2.FONT_HERSHEY_SIMPLEX, 0.55, (70,70,70), 2
    )

    canvas[GRID_H*CELL:GRID_H*CELL+110, 0:WIN_W] = hud


# ---------------------- ArUco helpers (compat) ----------------------
def make_params():
    if hasattr(cv2.aruco, "DetectorParameters"):
        return cv2.aruco.DetectorParameters()
    return cv2.aruco.DetectorParameters_create()

def make_detector(dictionary, params):
    if hasattr(cv2.aruco, "ArucoDetector"):
        return cv2.aruco.ArucoDetector(dictionary, params)
    return None

def detect(gray, dictionary, detector, params):
    if detector is not None:
        corners, ids, rejected = detector.detectMarkers(gray)
    else:
        corners, ids, rejected = cv2.aruco.detectMarkers(gray, dictionary, parameters=params)
    return corners, ids, rejected

def load_calibration(w, h, path=CALIB_FILE):
    try:
        data = np.load(path)
        K = data["camera_matrix"].astype(np.float32)
        dist = data["dist_coeffs"].astype(np.float32)
        return K, dist, True
    except Exception:
        fx = fy = 0.9 * w
        cx = w / 2.0
        cy = h / 2.0
        K = np.array([[fx, 0, cx],
                      [0, fy, cy],
                      [0,  0,  1]], dtype=np.float32)
        dist = np.zeros((5, 1), dtype=np.float32)
        return K, dist, False


def choose_id(ids_list):
    """Pick first ID that exists in CMD_MAP (prefer smaller IDs)."""
    for i in sorted(ids_list):
        if i in CMD_MAP:
            return i
    return None


def step_manual_move(agv: AGV, cmd: str):
    dx, dy = 0, 0
    if cmd == "FORWARD":   dy = -1
    if cmd == "BACKWARD":  dy = +1
    if cmd == "LEFT":      dx = -1
    if cmd == "RIGHT":     dx = +1
    nx, ny = agv.x + dx, agv.y + dy
    if is_free(nx, ny):
        agv.x, agv.y = nx, ny


def main():
    cap = cv2.VideoCapture(CAM_INDEX)
    if not cap.isOpened():
        raise RuntimeError(f"Cannot open camera index {CAM_INDEX}")

    ok, frame = cap.read()
    if not ok:
        raise RuntimeError("Cannot read from camera")
    h, w = frame.shape[:2]

    dictionary = cv2.aruco.getPredefinedDictionary(DICT)
    params = make_params()
    detector = make_detector(dictionary, params)

    K, dist, is_calib = load_calibration(w, h)
    draw_pose = True
    keyboard_control = False

    agv = AGV()
    agv.path = []
    mode = "MANUAL"
    mission = "Idle"

    last_cmd = "STOP"
    last_seen = 0.0
    last_move_t = time.time()

    print("Calibration:", "loaded" if is_calib else "NOT found (rough intrinsics)")

    while True:
        ok, frame = cap.read()
        if not ok:
            break

        # ---------- ArUco detect ----------
        gray = cv2.cvtColor(frame, cv2.COLOR_BGR2GRAY)
        corners, ids, _ = detect(gray, dictionary, detector, params)

        cmd = "STOP"
        chosen_id = None

        if ids is not None and len(ids) > 0:
            ids_list = ids.flatten().tolist()
            cv2.aruco.drawDetectedMarkers(frame, corners, ids)

            chosen_id = choose_id(ids_list)
            if chosen_id is not None:
                cmd = CMD_MAP[chosen_id]
                last_cmd = cmd
                last_seen = time.time()

                # Optional pose axes
                if draw_pose and cmd in ("FORWARD","BACKWARD","LEFT","RIGHT","STOP"):
                    try:
                        rvecs, tvecs, _ = cv2.aruco.estimatePoseSingleMarkers(
                            corners, MARKER_LENGTH_M, K, dist
                        )
                        idx = ids_list.index(chosen_id)
                        rvec = rvecs[idx]
                        tvec = tvecs[idx]
                        cv2.drawFrameAxes(frame, K, dist, rvec, tvec, MARKER_LENGTH_M * 0.75)
                        x = float(tvec[0][0])
                        z = float(tvec[0][2])
                        cv2.putText(frame, f"pose: x={x:+.3f}m z={z:.3f}m",
                                    (10, 60), cv2.FONT_HERSHEY_SIMPLEX, 0.65, (10,10,10), 2)
                    except Exception:
                        pass

        # Deadman hold
        if cmd == "STOP":
            if time.time() - last_seen < HOLD_SEC:
                cmd = last_cmd
            else:
                last_cmd = "STOP"

        # HUD on camera view
        cv2.rectangle(frame, (0, 0), (w, 44), (255, 255, 255), -1)
        cv2.putText(frame, f"CMD: {cmd}", (10, 32),
                    cv2.FONT_HERSHEY_SIMPLEX, 1.0, (0,0,0), 3)

        cv2.imshow("Webcam ArUco (phone -> cmd)", frame)

        # ---------- Warehouse sim draw ----------
        canvas = np.full((WIN_H, WIN_W, 3), 255, dtype=np.uint8)
        world = canvas[:GRID_H*CELL, :]

        draw_zone(world, RECEIVING,    "RECEIVING", (220,245,255))
        draw_zone(world, STORAGE_ZONE, "STORAGE",   (245,255,220))
        draw_zone(world, CHARGING,     "CHARGING",  (255,235,220))

        draw_grid(world)
        draw_obstacles(world)
        draw_target(world, TARGET_RECEIVING, "Pick")
        draw_target(world, TARGET_STORAGE, "Drop")
        draw_target(world, TARGET_CHARGING, "Charge")

        # battery sim
        moving = (mode == "AUTO" and agv.path) or (cmd in ("FORWARD","BACKWARD","LEFT","RIGHT") and not keyboard_control)
        if moving:
            agv.battery = max(0.0, agv.battery - 0.0018)
        else:
            agv.battery = max(0.0, agv.battery - 0.0003)
        if in_rect(agv.x, agv.y, CHARGING):
            agv.battery = min(1.0, agv.battery + 0.012)

        # ---------- Mission / movement ----------
        now = time.time()

        # If a mission marker is shown, start a path
        if cmd == "GO_RECEIVING":
            mode = "AUTO"
            mission = "Go RECEIVING"
            agv.path = astar((agv.x, agv.y), TARGET_RECEIVING)
        elif cmd == "GO_STORAGE":
            mode = "AUTO"
            mission = "Go STORAGE"
            agv.path = astar((agv.x, agv.y), TARGET_STORAGE)
        elif cmd == "GO_CHARGING":
            mode = "AUTO"
            mission = "Go CHARGING"
            agv.path = astar((agv.x, agv.y), TARGET_CHARGING)

        # AUTO follow path (one step per loop here; you can slow down if needed)
        if mode == "AUTO" and agv.path:
            nx, ny = agv.path.pop(0)
            agv.x, agv.y = nx, ny

        # Manual via ArUco directional commands (grid step every MOVE_PERIOD)
        if not keyboard_control and cmd in ("FORWARD", "BACKWARD", "LEFT", "RIGHT"):
            if now - last_move_t >= MOVE_PERIOD:
                mode = "MANUAL"
                mission = "Idle"
                agv.path = []
                step_manual_move(agv, cmd)
                last_move_t = now

        # Mission logic (pick -> drop -> charge if low)
        if mission == "Go RECEIVING" and (agv.x, agv.y) == TARGET_RECEIVING:
            agv.carrying = True
            mission = "Go STORAGE"
            agv.path = astar((agv.x, agv.y), TARGET_STORAGE)

        if mission == "Go STORAGE" and (agv.x, agv.y) == TARGET_STORAGE:
            agv.carrying = False
            if agv.battery < 0.35:
                mission = "Go CHARGING"
                agv.path = astar((agv.x, agv.y), TARGET_CHARGING)
            else:
                mission = "Idle"
                mode = "MANUAL"
                agv.path = []

        if mission == "Go CHARGING" and (agv.x, agv.y) == TARGET_CHARGING:
            if agv.battery > 0.85:
                mission = "Idle"
                mode = "MANUAL"
                agv.path = []

        draw_path(world, agv.path)
        draw_agv(world, agv)

        info = f"Mission: {mission} | Carrying: {agv.carrying}"
        draw_hud(canvas, agv, mode, info, cmd)

        cv2.imshow("Warehouse Sandbox (AGV)", canvas)

        # ---------- Key handling ----------
        key = cv2.waitKey(1) & 0xFF
        if key == ord("q"):
            break
        if key == ord("m"):
            draw_pose = not draw_pose
        if key == ord("k"):
            keyboard_control = not keyboard_control
        if key == ord("r"):
            agv.x, agv.y = 3, 17
            agv.battery = 1.0
            agv.carrying = False
            agv.path = []
            mode = "MANUAL"
            mission = "Idle"

        if keyboard_control and key in (ord('w'), ord('a'), ord('s'), ord('d')):
            mode = "MANUAL"
            mission = "Idle"
            agv.path = []
            kcmd = "STOP"
            if key == ord('w'): kcmd = "FORWARD"
            if key == ord('s'): kcmd = "BACKWARD"
            if key == ord('a'): kcmd = "LEFT"
            if key == ord('d'): kcmd = "RIGHT"
            step_manual_move(agv, kcmd)

    cap.release()
    cv2.destroyAllWindows()


if __name__ == "__main__":
    main()
