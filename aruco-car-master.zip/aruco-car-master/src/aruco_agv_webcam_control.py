
# aruco_agv_webcam_control.py
# Detect ArUco markers from a real webcam and map marker IDs to AGV commands:
#   ID 0 -> FORWARD
#   ID 1 -> BACKWARD
#   ID 2 -> TURN LEFT
#   ID 3 -> TURN RIGHT
#
# Install:
#   pip install opencv-contrib-python numpy
#
# Run:
#   python aruco_agv_webcam_control.py
#
# Tips:
# - Show the marker on your phone (full screen, high brightness).
# - Keep the marker flat to the camera and avoid motion blur.
# - If you have a calibrated camera, put camera_matrix & dist_coeffs in calib_cam.npz
#   with keys: "camera_matrix" and "dist_coeffs" (OpenCV format).
#
# Keys:
#   q  quit
#   s  save detected frame
#   m  toggle pose drawing (axes) on/off

import time
import math
import cv2
import numpy as np

# ------------------ Settings ------------------
CAM_INDEX = 0                 # change to 1,2... if you have multiple cameras
DICT = cv2.aruco.DICT_4X4_50  # ArUco dictionary
MARKER_LENGTH_M = 0.06        # physical marker size in meters (only for pose/axes)
CALIB_FILE = "calib_cam.npz"  # optional calibration

# Map marker IDs to commands
CMD_MAP = {
    0: "tien",
    1: "lui",
    2: "trai",
    3: "phai",
}

# Optional: "deadman" timeout so command goes to STOP when marker disappears
HOLD_SEC = 0.35

# ---------------------------------------------


def load_calibration(w, h, path=CALIB_FILE):
    """Load camera calibration if available; otherwise make a rough pinhole matrix."""
    try:
        data = np.load(path)
        K = data["camera_matrix"].astype(np.float32)
        dist = data["dist_coeffs"].astype(np.float32)
        return K, dist, True
    except Exception:
        # rough guess intrinsics (works OK for drawing axes but not precise)
        fx = fy = 0.9 * w
        cx = w / 2.0
        cy = h / 2.0
        K = np.array([[fx, 0, cx],
                      [0, fy, cy],
                      [0,  0,  1]], dtype=np.float32)
        dist = np.zeros((5, 1), dtype=np.float32)
        return K, dist, False


def make_params():
    if hasattr(cv2.aruco, "DetectorParameters"):
        return cv2.aruco.DetectorParameters()
    return cv2.aruco.DetectorParameters_create()


def make_detector(dictionary, params):
    if hasattr(cv2.aruco, "ArucoDetector"):
        return cv2.aruco.ArucoDetector(dictionary, params)
    return None


def detect(gray, dictionary, detector, params):
    if detector is not None:
        corners, ids, rejected = detector.detectMarkers(gray)
    else:
        corners, ids, rejected = cv2.aruco.detectMarkers(gray, dictionary, parameters=params)
    return corners, ids, rejected


def main():
    cap = cv2.VideoCapture(CAM_INDEX)
    if not cap.isOpened():
        raise RuntimeError(f"Cannot open camera index {CAM_INDEX}")

    # Read one frame to get size
    ok, frame = cap.read()
    if not ok:
        raise RuntimeError("Cannot read from camera")
    h, w = frame.shape[:2]

    dictionary = cv2.aruco.getPredefinedDictionary(DICT)
    params = make_params()
    detector = make_detector(dictionary, params)

    K, dist, is_calib = load_calibration(w, h)
    draw_pose = True

    last_cmd = "STOP"
    last_seen = 0.0
    fps_t0 = time.time()
    fps_n = 0
    fps = 0.0

    print("Calibration:", "loaded" if is_calib else "NOT found (using rough intrinsics)")

    while True:
        ok, frame = cap.read()
        if not ok:
            break

        gray = cv2.cvtColor(frame, cv2.COLOR_BGR2GRAY)
        corners, ids, _ = detect(gray, dictionary, detector, params)

        cmd = "STOP"

        if ids is not None and len(ids) > 0:
            # Choose the first detected marker (or you can choose the largest by area)
            ids_flat = ids.flatten().tolist()

            cv2.aruco.drawDetectedMarkers(frame, corners, ids)

            # Decide command based on the smallest id that exists in CMD_MAP
            chosen_id = None
            for i in ids_flat:
                if i in CMD_MAP:
                    chosen_id = i
                    break

            if chosen_id is not None:
                cmd = CMD_MAP[chosen_id]
                last_cmd = cmd
                last_seen = time.time()

                # Optional: pose estimation and axes drawing
                if draw_pose:
                    try:
                        rvecs, tvecs, _obj = cv2.aruco.estimatePoseSingleMarkers(
                            corners, MARKER_LENGTH_M, K, dist
                        )
                        # find index of chosen_id
                        idx = ids_flat.index(chosen_id)
                        rvec = rvecs[idx]
                        tvec = tvecs[idx]
                        cv2.drawFrameAxes(frame, K, dist, rvec, tvec, MARKER_LENGTH_M * 0.75)

                        x = float(tvec[0][0])
                        z = float(tvec[0][2])
                        cv2.putText(frame, f"pose: x={x:+.3f}m z={z:.3f}m",
                                    (10, 60), cv2.FONT_HERSHEY_SIMPLEX, 0.65, (10, 10, 10), 2)
                    except Exception:
                        pass

        # Deadman hold: if marker disappears quickly, keep last cmd for a short time
        if cmd == "STOP":
            if time.time() - last_seen < HOLD_SEC:
                cmd = last_cmd
            else:
                last_cmd = "STOP"

        # FPS counter
        fps_n += 1
        if fps_n >= 12:
            t = time.time()
            fps = fps_n / (t - fps_t0)
            fps_t0 = t
            fps_n = 0

        # HUD
        cv2.rectangle(frame, (0, 0), (w, 110), (255, 255, 255), -1)
        cv2.putText(frame, f"CMD: {cmd}", (10, 35),
                    cv2.FONT_HERSHEY_SIMPLEX, 1.0, (0, 0, 0), 3)
        cv2.putText(frame, f"IDs: {ids.flatten().tolist() if ids is not None else []}", (10, 95),
                    cv2.FONT_HERSHEY_SIMPLEX, 0.7, (30, 30, 30), 2)
        cv2.putText(frame, f"FPS: {fps:.1f} | PoseDraw: {'ON' if draw_pose else 'OFF'}",
                    (w - 350, 95), cv2.FONT_HERSHEY_SIMPLEX, 0.7, (30, 30, 30), 2)

        cv2.imshow("ArUco -> AGV Command (Webcam)", frame)

        key = cv2.waitKey(1) & 0xFF
        if key == ord("q"):
            break
        if key == ord("s"):
            cv2.imwrite("aruco_detect_frame.png", frame)
            print("Saved: aruco_detect_frame.png")
        if key == ord("m"):
            draw_pose = not draw_pose

    cap.release()
    cv2.destroyAllWindows()


if __name__ == "__main__":
    main()
