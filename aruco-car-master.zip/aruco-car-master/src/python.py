import socket

ESP32_IP = "192.168.1.50"   # Đổi thành IP in trên Serial Monitor
ESP32_PORT = 5000

def send_command(cmd: str):
    """
    Gửi 1 lệnh dạng chuỗi tới ESP32.
    Ví dụ:
        send_command("MOVE 20")
        send_command("TURN -30")
        send_command("STOP")
    """
    cmd = cmd.strip() + "\n"
    with socket.socket(socket.AF_INET, socket.SOCK_STREAM) as s:
        s.connect((ESP32_IP, ESP32_PORT))
        s.sendall(cmd.encode('utf-8'))
        # Ở đây server không gửi lại gì, nên không cần recv()
    print(f"Đã gửi: {cmd.strip()}")

if __name__ == "__main__":
    print("Nhập lệnh (ví dụ: MOVE 20, TURN -30, STOP). Gõ 'exit' để thoát.")
    while True:
        line = input(">>> ").strip()
        if line.lower() in ("exit", "quit"):
            break
        if not line:
            continue
        try:
            send_command(line)
        except Exception as e:
            print("Lỗi khi gửi lệnh:", e)
