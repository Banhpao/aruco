import time
import heapq
from dataclasses import dataclass

import cv2
import numpy as np

# ---------------------- Camera / ArUco config ----------------------
CAM_INDEX = 0
DICT = cv2.aruco.DICT_4X4_50
MARKER_LENGTH_M = 0.06
CALIB_FILE = "calib_cam.npz"

CMD_MAP = {
    0: "FORWARD",
    1: "BACKWARD",
    2: "LEFT",
    3: "RIGHT",
    4: "STOP",
    10: "GO_RECEIVING",
    11: "GO_STORAGE",
    12: "GO_CHARGING",
}

HOLD_SEC = 0.30
MOVE_PERIOD = 0.22

# ---------------------- Warehouse config ----------------------
CELL = 28
GRID_W, GRID_H = 32, 20
WIN_W = GRID_W * CELL
WIN_H = GRID_H * CELL + 110

RECEIVING = (1, 13, 8, 19)
CHARGING  = (24, 13, 31, 19)
STORAGE_ZONE = (10, 2, 22, 12)

TARGET_RECEIVING = (4, 16)
TARGET_STORAGE   = (20, 9)   # fixed: aisle cell
TARGET_CHARGING  = (27, 16)

def make_obstacles():
    occ = np.zeros((GRID_H, GRID_W), dtype=np.uint8)
    x0, y0, x1, y1 = STORAGE_ZONE
    for x in range(x0 + 1, x1 - 1, 3):
        for y in range(y0 + 1, y1 - 1):
            if y in (5, 6, 9):  # aisles
                continue
            occ[y, x] = 1
    for x in range(13, 16):
        if 0 <= 12 < GRID_H:
            occ[12, x] = 1
    return occ

OCC = make_obstacles()

@dataclass
class AGV:
    x: int = 3
    y: int = 17
    battery: float = 1.0
    carrying: bool = False
    path: list = None

def in_bounds(x, y): return 0 <= x < GRID_W and 0 <= y < GRID_H
def is_free(x, y): return in_bounds(x, y) and OCC[y, x] == 0

def astar(start, goal):
    sx, sy = start
    gx, gy = goal
    if not is_free(gx, gy):
        return []

    def h(x, y): return abs(x - gx) + abs(y - gy)

    open_heap = []
    heapq.heappush(open_heap, (h(sx, sy), 0, (sx, sy)))
    came = {(sx, sy): None}
    gscore = {(sx, sy): 0}

    while open_heap:
        _, g, (x, y) = heapq.heappop(open_heap)
        if (x, y) == (gx, gy):
            path = []
            cur = (x, y)
            while cur is not None:
                path.append(cur)
                cur = came[cur]
            path.reverse()
            return path[1:]

        for dx, dy in ((1,0), (-1,0), (0,1), (0,-1)):
            nx, ny = x + dx, y + dy
            if not is_free(nx, ny):
                continue
            ng = g + 1
            if (nx, ny) not in gscore or ng < gscore[(nx, ny)]:
                gscore[(nx, ny)] = ng
                came[(nx, ny)] = (x, y)
                heapq.heappush(open_heap, (ng + h(nx, ny), ng, (nx, ny)))
    return []

def cell_to_px(x, y): return int(x * CELL), int(y * CELL)

def draw_zone(img, rect, label, color):
    x0, y0, x1, y1 = rect
    px0, py0 = cell_to_px(x0, y0)
    cv2.rectangle(img, (px0, py0), (x1*CELL, y1*CELL), color, -1)
    cv2.rectangle(img, (px0, py0), (x1*CELL, y1*CELL), (60,60,60), 2)
    cv2.putText(img, label, (px0+6, py0+24), cv2.FONT_HERSHEY_SIMPLEX, 0.75, (20,20,20), 2)

def draw_grid(img):
    for x in range(GRID_W + 1):
        cv2.line(img, (x*CELL, 0), (x*CELL, GRID_H*CELL), (235,235,235), 1)
    for y in range(GRID_H + 1):
        cv2.line(img, (0, y*CELL), (GRID_W*CELL, y*CELL), (235,235,235), 1)

def draw_obstacles(img):
    ys, xs = np.where(OCC == 1)
    for y, x in zip(ys, xs):
        px, py = cell_to_px(x, y)
        cv2.rectangle(img, (px, py), (px+CELL, py+CELL), (110,110,110), -1)
        cv2.rectangle(img, (px, py), (px+CELL, py+CELL), (70,70,70), 1)

def draw_target(img, target, label):
    x, y = target
    px, py = cell_to_px(x, y)
    cv2.circle(img, (px+CELL//2, py+CELL//2), 9, (10,10,10), -1)
    cv2.putText(img, label, (px+CELL//2+10, py+CELL//2+6), cv2.FONT_HERSHEY_SIMPLEX, 0.55, (10,10,10), 2)

def draw_path(img, path):
    if not path: return
    for (x, y) in path:
        px, py = cell_to_px(x, y)
        cv2.rectangle(img, (px+8, py+8), (px+CELL-8, py+CELL-8), (40,180,40), -1)

def draw_agv(img, agv: AGV):
    px, py = cell_to_px(agv.x, agv.y)
    cx, cy = px + CELL//2, py + CELL//2
    cv2.circle(img, (cx, cy), 11, (40,40,230), -1)
    cv2.circle(img, (cx, cy), 11, (20,20,20), 2)
    if agv.carrying:
        cv2.rectangle(img, (cx-7, cy-20), (cx+7, cy-6), (0,0,0), -1)
        cv2.putText(img, "BOX", (cx-18, cy-25), cv2.FONT_HERSHEY_SIMPLEX, 0.45, (0,0,0), 2)

def in_rect(x, y, rect):
    x0, y0, x1, y1 = rect
    return x0 <= x < x1 and y0 <= y < y1

def draw_hud(canvas, agv: AGV, mode: str, info: str, cmd: str, warn: str):
    hud = np.full((110, WIN_W, 3), 255, dtype=np.uint8)
    bx0, by0 = 12, 18
    bw, bh = 210, 20
    cv2.rectangle(hud, (bx0, by0), (bx0+bw, by0+bh), (30,30,30), 2)
    fill = int(bw * max(0.0, min(1.0, agv.battery)))
    cv2.rectangle(hud, (bx0+2, by0+2), (bx0+2+fill, by0+bh-2), (40,180,40), -1)
    cv2.putText(hud, f"Battery: {agv.battery*100:.0f}%", (bx0, by0+50), cv2.FONT_HERSHEY_SIMPLEX, 0.75, (0,0,0), 2)

    cv2.putText(hud, f"Mode: {mode}", (260, 40), cv2.FONT_HERSHEY_SIMPLEX, 0.9, (0,0,0), 3)
    cv2.putText(hud, f"CMD: {cmd}", (260, 80), cv2.FONT_HERSHEY_SIMPLEX, 0.75, (0,0,0), 2)
    cv2.putText(hud, info, (520, 80), cv2.FONT_HERSHEY_SIMPLEX, 0.6, (30,30,30), 2)
    if warn:
        cv2.putText(hud, warn, (520, 40), cv2.FONT_HERSHEY_SIMPLEX, 0.7, (0,0,200), 2)

    cv2.putText(
        hud,
        "q quit | m pose | 1/2/3 missions | w/a/s/d move | r reset",
        (12, 102),
        cv2.FONT_HERSHEY_SIMPLEX, 0.55, (70,70,70), 2
    )
    canvas[GRID_H*CELL:GRID_H*CELL+110, 0:WIN_W] = hud

# ---------- ArUco compat ----------
def make_params():
    if hasattr(cv2.aruco, "DetectorParameters"):
        return cv2.aruco.DetectorParameters()
    return cv2.aruco.DetectorParameters_create()

def make_detector(dictionary, params):
    if hasattr(cv2.aruco, "ArucoDetector"):
        return cv2.aruco.ArucoDetector(dictionary, params)
    return None

def detect(gray, dictionary, detector, params):
    if detector is not None:
        corners, ids, _ = detector.detectMarkers(gray)
    else:
        corners, ids, _ = cv2.aruco.detectMarkers(gray, dictionary, parameters=params)
    return corners, ids

def load_calibration(w, h, path=CALIB_FILE):
    try:
        data = np.load(path)
        K = data["camera_matrix"].astype(np.float32)
        dist = data["dist_coeffs"].astype(np.float32)
        return K, dist, True
    except Exception:
        fx = fy = 0.9 * w
        cx = w / 2.0
        cy = h / 2.0
        K = np.array([[fx, 0, cx],
                      [0, fy, cy],
                      [0,  0,  1]], dtype=np.float32)
        dist = np.zeros((5, 1), dtype=np.float32)
        return K, dist, False

def choose_id(ids_list):
    for i in sorted(ids_list):
        if i in CMD_MAP:
            return i
    return None

def step_move(agv: AGV, cmd: str):
    dx, dy = 0, 0
    if cmd == "FORWARD": dy = -1
    if cmd == "BACKWARD": dy = +1
    if cmd == "LEFT": dx = -1
    if cmd == "RIGHT": dx = +1
    nx, ny = agv.x + dx, agv.y + dy
    if is_free(nx, ny):
        agv.x, agv.y = nx, ny

def start_mission(agv: AGV, mission: str):
    if mission == "Go RECEIVING":
        return astar((agv.x, agv.y), TARGET_RECEIVING)
    if mission == "Go STORAGE":
        return astar((agv.x, agv.y), TARGET_STORAGE)
    if mission == "Go CHARGING":
        return astar((agv.x, agv.y), TARGET_CHARGING)
    return []

# ---------- Pose -> CamPos ----------
def rotmat_to_euler_zyx(R):
    """
    Return yaw(Z), pitch(Y), roll(X) for rotation matrix using ZYX convention.
    """
    sy = np.sqrt(R[0,0]*R[0,0] + R[1,0]*R[1,0])
    singular = sy < 1e-6
    if not singular:
        yaw = np.arctan2(R[1,0], R[0,0])
        pitch = np.arctan2(-R[2,0], sy)
        roll = np.arctan2(R[2,1], R[2,2])
    else:
        yaw = np.arctan2(-R[0,1], R[1,1])
        pitch = np.arctan2(-R[2,0], sy)
        roll = 0
    return yaw, pitch, roll

def cam_pos_text(rvec, tvec):
    """
    Pose from estimatePoseSingleMarkers is marker->camera:
      X_c = R * X_m + t
    Camera position in marker frame:
      C_m = -R^T * t
    """
    R, _ = cv2.Rodrigues(rvec)
    C = -R.T @ tvec.reshape(3,1)
    x_mm = float(C[0,0] * 1000.0)
    y_mm = float(C[1,0] * 1000.0)
    # camera orientation in marker frame:
    R_cm = R.T
    yaw, pitch, roll = rotmat_to_euler_zyx(R_cm)
    rot_deg = float(np.degrees(yaw))
    return x_mm, y_mm, rot_deg

def main():
    cap = cv2.VideoCapture(CAM_INDEX)
    if not cap.isOpened():
        raise RuntimeError(f"Cannot open camera index {CAM_INDEX}")

    ok, frame = cap.read()
    if not ok:
        raise RuntimeError("Cannot read from camera")
    h, w = frame.shape[:2]

    dictionary = cv2.aruco.getPredefinedDictionary(DICT)
    params = make_params()
    detector = make_detector(dictionary, params)

    K, dist, is_calib = load_calibration(w, h)
    draw_pose = True

    agv = AGV()
    agv.path = []
    mode = "MANUAL"
    mission = "Idle"
    warn = ""

    last_cmd = "STOP"
    last_seen = 0.0
    last_move_t = time.time()

    print("Calibration:", "loaded" if is_calib else "NOT found (rough intrinsics)")
    print("TIP: Use marker 10/11/12 for missions, or press 1/2/3 on keyboard.")

    while True:
        ok, frame = cap.read()
        if not ok:
            break

        gray = cv2.cvtColor(frame, cv2.COLOR_BGR2GRAY)
        corners, ids = detect(gray, dictionary, detector, params)

        cmd = "STOP"
        chosen_id = None
        campos_overlay = None  # (x_mm, y_mm, rot_deg)

        if ids is not None and len(ids) > 0:
            ids_list = ids.flatten().tolist()
            cv2.aruco.drawDetectedMarkers(frame, corners, ids)

            chosen_id = choose_id(ids_list)
            if chosen_id is not None:
                cmd = CMD_MAP[chosen_id]
                last_cmd = cmd
                last_seen = time.time()

                # Estimate pose of all detected markers
                try:
                    rvecs, tvecs, _ = cv2.aruco.estimatePoseSingleMarkers(
                        corners, MARKER_LENGTH_M, K, dist
                    )
                    idx = ids_list.index(chosen_id)
                    rvec = rvecs[idx].reshape(3,1)
                    tvec = tvecs[idx].reshape(3,1)

                    # Pose axes
                    if draw_pose and cmd in ("FORWARD","BACKWARD","LEFT","RIGHT","STOP"):
                        cv2.drawFrameAxes(frame, K, dist, rvec, tvec, MARKER_LENGTH_M * 0.75)

                    # CamPos overlay (works for any marker)
                    campos_overlay = cam_pos_text(rvec, tvec)
                except Exception:
                    pass

        # Deadman hold
        if cmd == "STOP":
            if time.time() - last_seen < HOLD_SEC:
                cmd = last_cmd
            else:
                last_cmd = "STOP"

        # Camera HUD
        cv2.rectangle(frame, (0, 0), (w, 56), (255, 255, 255), -1)
        cv2.putText(frame, f"CMD: {cmd}", (10, 38),
                    cv2.FONT_HERSHEY_SIMPLEX, 1.0, (0,0,0), 3)

        # Bottom CamPos text like your example (red)
        if campos_overlay is not None:
            x_mm, y_mm, rot_deg = campos_overlay
            text = f"CamPos  x={x_mm:.0f}  y={y_mm:.0f}  rot={rot_deg:.0f}"
            # big red text near bottom
            cv2.putText(frame, text, (14, h - 18),
                        cv2.FONT_HERSHEY_SIMPLEX, 1.2, (0,0,255), 4, cv2.LINE_AA)

        cv2.imshow("Webcam ArUco (phone -> cmd)", frame)

        # ---------- Apply cmd to sim ----------
        warn = ""
        if cmd == "GO_RECEIVING":
            mode, mission = "AUTO", "Go RECEIVING"
            agv.path = start_mission(agv, mission)
            if not agv.path:
                warn = "WARN: No path to RECEIVING"
        elif cmd == "GO_STORAGE":
            mode, mission = "AUTO", "Go STORAGE"
            agv.path = start_mission(agv, mission)
            if not agv.path:
                warn = "WARN: No path to STORAGE"
        elif cmd == "GO_CHARGING":
            mode, mission = "AUTO", "Go CHARGING"
            agv.path = start_mission(agv, mission)
            if not agv.path:
                warn = "WARN: No path to CHARGING"

        # AUTO follow path
        if mode == "AUTO" and agv.path:
            nx, ny = agv.path.pop(0)
            agv.x, agv.y = nx, ny

        # Directional manual via ArUco
        now = time.time()
        if cmd in ("FORWARD","BACKWARD","LEFT","RIGHT"):
            if now - last_move_t >= MOVE_PERIOD:
                mode, mission = "MANUAL", "Idle"
                agv.path = []
                step_move(agv, cmd)
                last_move_t = now

        # battery & charging
        moving = (mode == "AUTO" and bool(agv.path)) or (cmd in ("FORWARD","BACKWARD","LEFT","RIGHT"))
        agv.battery = max(0.0, agv.battery - (0.0018 if moving else 0.0003))
        if in_rect(agv.x, agv.y, CHARGING):
            agv.battery = min(1.0, agv.battery + 0.012)

        # mission chaining
        if mission == "Go RECEIVING" and (agv.x, agv.y) == TARGET_RECEIVING:
            agv.carrying = True
            mission = "Go STORAGE"
            mode = "AUTO"
            agv.path = start_mission(agv, mission)
            if not agv.path:
                warn = "WARN: Storage target blocked?"
        if mission == "Go STORAGE" and (agv.x, agv.y) == TARGET_STORAGE:
            agv.carrying = False
            if agv.battery < 0.35:
                mission = "Go CHARGING"
                mode = "AUTO"
                agv.path = start_mission(agv, mission)
            else:
                mission, mode, agv.path = "Idle", "MANUAL", []
        if mission == "Go CHARGING" and (agv.x, agv.y) == TARGET_CHARGING:
            if agv.battery > 0.85:
                mission, mode, agv.path = "Idle", "MANUAL", []

        # ---------- Draw warehouse ----------
        canvas = np.full((WIN_H, WIN_W, 3), 255, dtype=np.uint8)
        world = canvas[:GRID_H*CELL, :]

        draw_zone(world, RECEIVING, "RECEIVING", (220,245,255))
        draw_zone(world, STORAGE_ZONE, "STORAGE", (245,255,220))
        draw_zone(world, CHARGING, "CHARGING", (255,235,220))

        draw_grid(world)
        draw_obstacles(world)
        draw_target(world, TARGET_RECEIVING, "Pick")
        draw_target(world, TARGET_STORAGE, "Drop")
        draw_target(world, TARGET_CHARGING, "Charge")

        draw_path(world, agv.path)
        draw_agv(world, agv)

        info = f"Mission: {mission} | Carrying: {agv.carrying}"
        draw_hud(canvas, agv, mode, info, cmd, warn)
        cv2.imshow("Warehouse Sandbox (AGV)", canvas)

        # ---------- Keys ----------
        key = cv2.waitKey(1) & 0xFF
        if key == ord("q"):
            break
        if key == ord("m"):
            draw_pose = not draw_pose
        if key == ord("r"):
            agv.x, agv.y = 3, 17
            agv.battery = 1.0
            agv.carrying = False
            agv.path = []
            mode = "MANUAL"
            mission = "Idle"

        # keyboard missions
        if key == ord('1'):
            mode, mission = "AUTO", "Go RECEIVING"
            agv.path = start_mission(agv, mission)
        if key == ord('2'):
            mode, mission = "AUTO", "Go STORAGE"
            agv.path = start_mission(agv, mission)
        if key == ord('3'):
            mode, mission = "AUTO", "Go CHARGING"
            agv.path = start_mission(agv, mission)

        # keyboard manual
        if key in (ord('w'), ord('a'), ord('s'), ord('d')):
            mode, mission = "MANUAL", "Idle"
            agv.path = []
            kcmd = "STOP"
            if key == ord('w'): kcmd = "FORWARD"
            if key == ord('s'): kcmd = "BACKWARD"
            if key == ord('a'): kcmd = "LEFT"
            if key == ord('d'): kcmd = "RIGHT"
            step_move(agv, kcmd)

    cap.release()
    cv2.destroyAllWindows()

if __name__ == "__main__":
    main()
